const {createAddress,getAllAddress,getAddressByUserId,deleteAddressById} = require('./address.service')
module.exports = ({
    createAddresses:(req, res) => {
        createAddress(req, (err, data) => {
            if (err) {
                res.json({
                    success: 0,
                    msg: "error while inserting" + err
                })
            } else {
                res.json({
                    success: 1,
                    result: data
                })
            }
        })
    },
    getAllAddresses: (req, res) => {
        getAllAddress(req, (err, data) => {
            if (err) {
                res.json({
                    success: 0,
                    msg: "error while fetching " + err
                })
            } else {
                res.json({
                    success: 1,
                    result: data
                })
            }
        })
    },
    getAddressesByUserId: (req, res) => {
        getAddressByUserId(req, (err, data) => {
            if (err) {
                res.json({
                    success: 0,
                    msg: "error while fetching " + err
                })
            } else {
                res.json({
                    success: 1,
                    result: data
                })
            }
        })
    },
    deleteAddressesById: (req, res) => {
        deleteAddressById(req, (err, data) => {
            if (err) {
                res.json({
                    success: 0,
                    msg: "error while fetching " + err
                })
            } else {
                res.json({
                    success: 1,
                    message:"Address deleted successfully"
                })
            }
        })
    }
})